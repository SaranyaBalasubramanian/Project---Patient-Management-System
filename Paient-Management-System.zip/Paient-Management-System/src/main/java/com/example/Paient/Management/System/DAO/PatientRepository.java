package com.example.Paient.Management.System.DAO;

import com.example.Paient.Management.System.enitity.Patient;
import org.springframework.data.jpa.repository.JpaRepository;


public interface PatientRepository extends JpaRepository<Patient, Integer>
{

}