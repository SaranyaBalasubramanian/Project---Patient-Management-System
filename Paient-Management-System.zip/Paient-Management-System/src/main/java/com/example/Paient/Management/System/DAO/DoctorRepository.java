package com.example.Paient.Management.System.DAO;

import com.example.Paient.Management.System.enitity.Doctor;
import org.springframework.data.jpa.repository.JpaRepository;


public interface DoctorRepository extends JpaRepository<Doctor, Integer>
{

}