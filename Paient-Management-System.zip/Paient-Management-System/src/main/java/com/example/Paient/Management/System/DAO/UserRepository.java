package com.example.Paient.Management.System.DAO;

import com.example.Paient.Management.System.enitity.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Integer>
{
}
