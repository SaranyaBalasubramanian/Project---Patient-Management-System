package com.example.Paient.Management.System.DAO;

import com.example.Paient.Management.System.enitity.Appointment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AppointmentRepository extends JpaRepository<Appointment, Integer> {
}