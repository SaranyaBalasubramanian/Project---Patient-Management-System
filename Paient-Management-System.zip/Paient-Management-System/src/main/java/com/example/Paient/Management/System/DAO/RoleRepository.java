package com.example.Paient.Management.System.DAO;

import com.example.Paient.Management.System.enitity.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role, Integer>
{
}
