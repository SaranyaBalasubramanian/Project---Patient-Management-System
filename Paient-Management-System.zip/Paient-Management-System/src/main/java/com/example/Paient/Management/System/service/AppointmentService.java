package com.example.Paient.Management.System.service;

import com.example.Paient.Management.System.DAO.AppointmentRepository;
import com.example.Paient.Management.System.DAO.DiseaseRepository;
import com.example.Paient.Management.System.enitity.Appointment;
import com.example.Paient.Management.System.enitity.Disease;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class AppointmentService {
    private AppointmentRepository appointmentRepository;

    @Autowired
    public AppointmentService(AppointmentRepository appointmentRepository)
    {
        this.appointmentRepository= appointmentRepository;
    }



    public List<Appointment> getAllAppointment()
    {
        List<Appointment> appointmentList = appointmentRepository.findAll();
        return appointmentList;
    }

    public void save(Appointment appointment)
    {
        appointmentRepository.save(appointment);
    }

    public Appointment findById(int id)
    {
        Appointment newAppointment =null;
        Optional<Appointment> appointment = appointmentRepository.findById(id);
        if(appointment.isPresent())
        {
            newAppointment = appointment.get();
        }
        return newAppointment;
    }


    public void deleteById(int id)
    {
        appointmentRepository.deleteById(id);
    }

}
