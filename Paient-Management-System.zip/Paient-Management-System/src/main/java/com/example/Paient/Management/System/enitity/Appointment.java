package com.example.Paient.Management.System.enitity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "appointment")
public class Appointment {
    @jakarta.persistence.Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="id")
    private int Id;
    @Column(name="name")
    private String name;
    @Column(name="email")
    private String email;
    @Column(name="date_of_appointment")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date dateOfAppointment;
    @Column(name="mobile")
    private String mobile;
    @Column(name="message")
    private String message;

//    @OneToMany(fetch = FetchType.LAZY,
//            mappedBy = "appointment",
//            cascade = {CascadeType.DETACH, CascadeType.MERGE,
//                    CascadeType.PERSIST, CascadeType.REFRESH})
//    public List<Doctor> doctors;


    public Appointment()
    {
        // empty constructor.
    }

    public Appointment(String name, String email, Date dateOfAppointment, String mobile, String message) {
        name = name;
        this.email = email;
        this.dateOfAppointment = dateOfAppointment;
        this.mobile = mobile;
        this.message = message;
    }

//    public List<Doctor> getDoctors()
//    {
//        return doctors;
//    }
//
//    public void setDoctors(List<Doctor> doctors)
//    {
//        this.doctors = doctors;
//    }
//
//    public void addDoctor(Doctor doctor)
//    {
//        if(doctors == null)
//        {
//            doctors = new ArrayList<>();
//        }
//        doctors.add(doctor);
//    }

    public Appointment(int id, String name, String email,Date dateOfAppointment,String mobile,String message)
    {
        this.Id = id;
        this.name = name;
        this.email = email;
        this.dateOfAppointment = dateOfAppointment;
        this.mobile = mobile;
        this.message = message;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getDateOfAppointment() {
        return dateOfAppointment;
    }

    public void setDateOfAppointment(Date dateOfAppointment) {
        this.dateOfAppointment = dateOfAppointment;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 79 * hash + Objects.hashCode(this.Id);
        hash = 79 * hash + Objects.hashCode(this.name);
        hash = 79 * hash + Objects.hashCode(this.email);
        hash = 79 * hash + Objects.hashCode(this.dateOfAppointment);
        hash = 79 * hash + Objects.hashCode(this.mobile);
        hash = 79 * hash + Objects.hashCode(this.message);
        return hash;
    }

    @Override
    public String toString() {
        return "Appointment{" +
                "Id=" + Id +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", dateOfAppointment=" + dateOfAppointment +
                ", mobile='" + mobile + '\'' +
                ", message='" + message +
//                ", doctors=" + doctors +
                '}';
    }
}
