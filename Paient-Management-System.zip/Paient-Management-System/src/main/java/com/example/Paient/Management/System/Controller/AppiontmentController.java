package com.example.Paient.Management.System.Controller;

import com.example.Paient.Management.System.enitity.Appointment;
import com.example.Paient.Management.System.enitity.Doctor;
import com.example.Paient.Management.System.service.AppointmentService;
import com.example.Paient.Management.System.service.DoctorService;
import com.example.Paient.Management.System.service.PatientService;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@Controller
@RequestMapping("/appointment")
public class AppiontmentController {

    // load employee data
    private DoctorService doctorService;
    private PatientService patientService;
    private AppointmentService appointmentService;
    private List<Appointment> theAppointment;

    public AppiontmentController(DoctorService doctorService, PatientService patientService, AppointmentService appiontmentService)
    {
        this.doctorService = doctorService;
        this.patientService = patientService;
        this.appointmentService = appiontmentService;
    }

    @GetMapping("/list")
    public String listDoctors(Model theModel)
    {
        theModel.addAttribute("appointmentList",appointmentService.getAllAppointment());
        return "appointment/list-appointment";
    }

    @GetMapping("/addAppointment")
    public String getDoctorForm(Model model)
    {
        Appointment appointment = new Appointment();
        model.addAttribute("appointment",appointment);
        return "appointment/addAppointment";
    }

    @PostMapping("/save")
    public String saveDoctor(@ModelAttribute("appointment") Appointment theAppointment)
    {
        appointmentService.save(theAppointment);
        return "redirect:/appointment/list";
    }

    @GetMapping("/showFormForUpdate")
    public String showUpdateForm(@RequestParam("appointmentId") int theID, Model model)
    {
        model.addAttribute("appointment",appointmentService.findById(theID));
        return "appointment/addAppointment";
    }

    @Autowired
    @PersistenceContext
    private EntityManager em;
    @GetMapping("/delete")
    @Transactional
    public String deleteDoctor(@RequestParam("appointmentId") int theID)
    {
        Appointment a = em.find(Appointment.class, theID);
//        for (Doctor b : a.getDoctors()) {
//            if (b.getAppointment() !=null)
//            {
//                em.remove(a);
//            }
//        }
        em.remove(a);
        //diseaseService.deleteById(theID);
        return "redirect:/appointment/list";
    }
}









