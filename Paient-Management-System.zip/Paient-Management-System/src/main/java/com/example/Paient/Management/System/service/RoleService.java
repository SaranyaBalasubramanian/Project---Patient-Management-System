package com.example.Paient.Management.System.service;

import com.example.Paient.Management.System.DAO.RoleRepository;
import com.example.Paient.Management.System.enitity.Role;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoleService
{
    @Autowired
    private RoleRepository roleRepository;

    public List<Role> getRoles()
    {
        return roleRepository.findAll();
    }
}
