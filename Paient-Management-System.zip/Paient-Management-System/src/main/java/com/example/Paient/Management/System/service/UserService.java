package com.example.Paient.Management.System.service;

import com.example.Paient.Management.System.DAO.UserRepository;
import com.example.Paient.Management.System.enitity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService
{
    @Autowired
    private UserRepository repository;

    public UserService(UserRepository userRepository)
    {
        this.repository = userRepository;
    }
    public void save(User user)
    {
        try
        {
            repository.save(user);
        }catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}
