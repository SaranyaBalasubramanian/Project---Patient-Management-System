package com.example.Paient.Management.System.DAO;

import com.example.Paient.Management.System.enitity.Disease;
import org.springframework.data.jpa.repository.JpaRepository;


public interface DiseaseRepository extends JpaRepository<Disease, Integer>
{

}
